# @sampatel3/console-tokens

Semantic CSS and deeply frozen JavaScript token exports for the Console Standard.
The package contains no application behavior, fonts, framework dependency,
network request or storage access.

Import the complete contract once:

```css
@import "@sampatel3/console-tokens/styles.css";
```

Apply the namespaced attributes to an application root:

```html
<div
  data-cs-app
  data-cs-product="worker"
  data-cs-theme="light"
  data-cs-density="compact"
></div>
```

Token values come from `src/tokens.json`, the release version comes from the
package manifest, and every file in `dist/` is generated.
