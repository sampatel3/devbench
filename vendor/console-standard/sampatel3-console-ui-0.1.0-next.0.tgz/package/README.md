# @sampatel3/console-ui

Framework-neutral React primitives for operational consoles. React and React
DOM are peers (`>=18.3 <20`); the package does not bundle React and has no Next,
Vite, router, Tailwind or icon-library dependency.

Import the stylesheet once at the application root:

```ts
import "@sampatel3/console-ui/styles.css";
```

Then wrap product UI with the explicit runtime contract:

```tsx
import { ConsoleRoot } from "@sampatel3/console-ui/server";

<ConsoleRoot product="worker" theme="light" density="compact">
  {children}
</ConsoleRoot>;
```

Use `@sampatel3/console-ui/server` for hook-free render primitives and
`@sampatel3/console-ui/interactive` for fields, tabs, toasts and dialogs. The
root export is a client-compatible convenience entry that re-exports both.

Applications retain ownership of routing, icons, sorting, filtering, data,
actions and business rules. This package performs no network calls, storage or
environment reads.
